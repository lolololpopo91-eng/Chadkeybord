package com.chadkeyboard.ime;

import android.inputmethodservice.InputMethodService;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.content.Context;
import android.view.inputmethod.EditorInfo;
import android.view.KeyEvent;

public class ChadInputMethodService extends InputMethodService {
    private WebView webView;

    @Override
    public View onCreateInputView() {
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF111018);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(false);
        webView.addJavascriptInterface(new KeyboardBridge(), "Chad");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/keyboard.html");
        return webView;
    }

    @Override
    public void onStartInput(EditorInfo attribute, boolean restarting) {
        super.onStartInput(attribute, restarting);
        if (webView != null) webView.evaluateJavascript("if(window.resetKeyboard) resetKeyboard();", null);
    }

    @Override
    public void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private class KeyboardBridge {
        @JavascriptInterface
        public void type(String text) {
            InputConnection ic = getCurrentInputConnection();
            if (ic != null && text != null) ic.commitText(text, 1);
        }

        @JavascriptInterface
        public void backspace() {
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) {
                CharSequence selected = ic.getSelectedText(0);
                if (selected != null && selected.length() > 0) ic.commitText("", 1);
                else ic.deleteSurroundingText(1, 0);
            }
        }

        @JavascriptInterface
        public void enter() {
            InputConnection ic = getCurrentInputConnection();
            if (ic == null) return;
            EditorInfo info = getCurrentInputEditorInfo();
            if (info != null && (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
                int action = info.imeOptions & EditorInfo.IME_MASK_ACTION;
                if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                    ic.performEditorAction(action);
                    return;
                }
            }
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
        }
    }
}
